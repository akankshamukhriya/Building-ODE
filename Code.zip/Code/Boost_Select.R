



# boost select ...................... (boosting with Avg and Greedy way of corrleation)

current_prediction <- function(EE, EE_NORM)
{
  cp = matrix(, nrow= points, ncol= 1);
  de = dim(EE);
  dime = de[2];
  
  for(i in 1:points)
  {
    cp[i,1] = 0;
    for(jj in 1:dime)
    {
      cp[i,1] = cp[i,1] + EE_NORM[i,jj];
    }
    cp[i,1] = cp[i,1] / dime;
  }
  
  return(cp);
}

convert_binary <- function(tar1, t1)
{
  points = dim(tar1)[1]
  top_nt1 = floor(points*t1)
  tar2 = matrix(data=0, nrow =points, ncol=1)
  temp_etc_SORT = matrix(data=0, nrow =points, ncol=1)
  temp_etc_IND = matrix(data=0, nrow =points, ncol=1)
  
  temp_etc = sort(tar1[,1], decreasing= TRUE, index.return = TRUE);
  temp_etc_SORT[,1]= as.matrix(temp_etc$x);
  temp_etc_IND[,1] = as.matrix(temp_etc$ix);
  
  
  for(i11 in 1:top_nt1)
    
  {
    tar2[temp_etc_IND[i11,1],1] = 1
  }
  
  return(tar2);
}

 boosting1 <- function(tar3_pass, W3_pass, t_pass, d_pass, boost_j, SCORE_LIST_SET_NORM)
{
   
points_pass = dim(W3_pass)[1]
outliers_included = matrix(data=0, nrow =points_pass, ncol=1)
temp2_pass = matrix(data=0, nrow =points_pass, ncol=1)

temp2_pass = as.matrix(SCORE_LIST_SET_NORM[,boost_j])
outliers_included = convert_binary(temp2_pass,t_pass)

#drop = 0.25
chk_pt =0
for(i in 1:points_pass)
{
  if((tar3_pass[i,1]==1)&&(outliers_included[i,1]==1))
  { 
    chk_pt = chk_pt+1
    W3_pass[i,1] = W3_pass[i,1]*d_pass
  }
}
chk_pt

 return(W3_pass)
} # END OF THE FUNCTION ........................................................
 # .................................................................................
 #.............................................................................
 #..................................................................
 #......................................................
 

#SCORE_LIST_SET = as.matrix(ANN7200_RANDOM33)
#SCORE_LIST_SET_NORM = as.matrix(ANN7200_RANDOM33_BZ)
#SCORE_LIST_SET_IND = as.matrix(ANN7200_RANDOM33_IND)

#SCORE_LIST_SET_NORM2 = as.matrix(MUSK_EN33_KNNLOFSOD)
#out_count  = 347


SCORE_LIST_SET = as.matrix(PEND_EN33_KNNLOFSOD)
SCORE_LIST_SET_NORM = as.matrix(PEND_EN33_KNNLOFSOD_BZ)
SCORE_LIST_SET_IND = as.matrix(PEND_EN33_KNNLOFSOD_IND)

t = 0.05
#d = 0.25

points = dim(SCORE_LIST_SET)[1]
members = dim(SCORE_LIST_SET)[2]

temp_target = matrix(data=0, nrow = points, ncol=1)
temp_target_SORT = matrix(data=0, nrow = points, ncol=1)
temp_target_IND = matrix(data=0, nrow = points, ncol=1)

#target3 = matrix(data=0, nrow = points, ncol=1)


for(i in 1:points)
{
  temp_target[i,1] = mean(SCORE_LIST_SET_NORM[i,])  
}

# convert binary ............................................................

top_nt = floor(points*t)

tempp = sort(temp_target[,1], decreasing= TRUE, index.return = TRUE);
temp_target_SORT[,1]= as.matrix(tempp$x);
temp_target_IND[,1] = as.matrix(tempp$ix);


#for(i in 1:top_nt)
#{
 # target3[temp_target_IND[i,1],1] = 1
#}

target3 = convert_binary(temp_target, t)
  


W3 = matrix(data =0, nrow = points, ncol = 1);

wout = 1/(2*top_nt);
win = 1/(2*(points-top_nt));

for(i in 1:points)
{
  if(target3[i,1] == 1)
  { 
    W3[i,1] = wout;    
  }
  else
  { 
    W3[i,1] = win;  
  }
}

library(weights)

library(wCorr)

corr = matrix(, nrow = members, ncol = 4);
#acc_values = matrix(data=0, nrow = members, ncol=1)
#acc_values_norm = matrix(data=0, nrow = members, ncol=1)

for(i in 1:members)
{
  corr[i,] = wtd.cor(SCORE_LIST_SET_NORM[,i],target3, W3[,1]);
  #corr[i,] =  weightedCorr(SCORE_LIST_SET_NORM[,i],target3, method = "Spearman", weights = W3[,1], ML = FALSE, fast = TRUE)
  #acc_values[i,] = corr[i,1]
} 

#acc3_values = matrix(data=0, nrow = members, ncol=1)

#acc3_values[,1] = corr[,1]

corr_sort = sort(corr[,1], decreasing = TRUE, index.return = TRUE);
corr_ind <- as.matrix(corr_sort$ix);
corr_sort_mat <- as.matrix(corr_sort$x);



selected3 = matrix(data =0, nrow = members, ncol = 1); 
considered3 = matrix(data =0, nrow =members, ncol =1);


kk = 1;

E = matrix(, nrow = points);
E_NORM = matrix(, nrow = points);
p = matrix(, nrow = points);


E[,kk] = SCORE_LIST_SET[,corr_ind[1,1]];
E_NORM[,kk] = SCORE_LIST_SET_NORM[,corr_ind[1,1]];

p[,1] = E_NORM[,kk];

selected3[corr_ind[1,1],1] = 1;
considered3[corr_ind[1,1],1] = 1;

# sorting I by Wpearson correaltion to p

corr_p = matrix(, nrow = members, ncol = 4);
rem=0;

for(i in 1:members)
{
  if(considered3[i,1] == 0)
    {
    corr_p[i,] = wtd.cor(SCORE_LIST_SET_NORM[,i],p[,1], W3[,1]);
    #corr_p[i,] = weightedCorr(SCORE_LIST_SET_NORM[,i],p[,1], method = "Spearman", weights = W3[,1], ML = FALSE, fast = TRUE)
    rem = rem +1;
  }
  else{
    
    corr_p[i,1] = 1000;
    corr_p[i,2] = 20;
    corr_p[i,3] = 20
    corr_p[i,4] = 20;
  }
} 


corrp_sort = sort(corr_p[,1], decreasing = FALSE, index.return = TRUE);
corrp_ind <- as.matrix(corrp_sort$ix);

#NE = norm1(E)


#p_v = current_prediction(E_NORM);
p_v = current_prediction(E,E_NORM);

count =members-1;
ns =1;

while(count >0)
{
  ns =1;
  j = corrp_ind[ns,1];
  fc=0;
  
  while((considered3[j,1] == 1)&&(ns<members))
  {
    if(considered3[j,1] == 1)
    { 
      ns = ns +1;
      j = corrp_ind[ns,1];
      fc=fc+1;
    } 
  }
  
  considered3[j,1] = 1;
  d = dim(E);
  d1 = d[2];
  E1 = matrix(, nrow = points, ncol = d1+1);
  E1_NORM = matrix(, nrow = points, ncol = d1+1);
  E1[,1:d1] = E[,1:d1];
  E1_NORM[,1:d1] = E_NORM[,1:d1];
  E1[,d1+1] = SCORE_LIST_SET[,j];
  E1_NORM[,d1+1] = SCORE_LIST_SET_NORM[,j];
  x =d1+1;
  
  E1_UNI = matrix(data =0, nrow =points, ncol = 1);
  #NE = norm1(E1)
  
  #for(xxx in 1:points)
  #{
  #E1_UNI = current_prediction(E1_NORM);
  E1_UNI = current_prediction(E1,E1_NORM);
  #}
  
  # NE = norm1(E)
  
  
  
  #p_v = current_prediction(E_NORM);
  p_v = current_prediction(E,E_NORM);
  
  
  wp_ejv = wtd.cor(E1_UNI[,1],target3[,1], W3[,1]);
  #wp_ejv = weightedCorr(E1_UNI[,1],target3[,1], method = "Spearman", weights = W3[,1], ML = FALSE, fast = TRUE)
  
  wp_ev = wtd.cor(p_v[,1],target3[,1], W3[,1]);
  #wp_ev = weightedCorr(p_v[,1],target3[,1], method = "Spearman", weights = W3[,1], ML = FALSE, fast = TRUE)
  
  #good_old = goodness(as.matrix(p_v))
  #good_new = goodness(as.matrix(KW5_OPT[,1]))
  
  
  if(wp_ejv[1,1] > wp_ev[1,1])
  {
    #flag = 1;
    selected3[j,1] =1;
    boost_j =j;
    
    k1 = dim(E)[2];
    E_NEW = matrix(, nrow = points, ncol = k1+1);
    E_NEW_NORM = matrix(, nrow = points, ncol = k1+1);
    
    E_NEW[,1:k1] = E[,];
    E_NEW_NORM[,1:k1] = E_NORM[,];
    E_NEW[,k1+1] = SCORE_LIST_SET[,j];
    E_NEW_NORM[,k1+1] = SCORE_LIST_SET_NORM[,j];
    E = E_NEW;
    E_NORM = E_NEW_NORM;
    #NE = norm1(E)
    
    
    #p = current_prediction(E_NORM);
    p = current_prediction(E,E_NORM);
    
    # rem =0;
    for(m in 1:members)
    {
      if(considered3[m,1] ==0)
        rem = rem+1;
    }
    
    # sorting I by Wpearson correaltion to p
    corr_p = matrix(, nrow = members, ncol = 4);
    
    #J=0;
    for(i in 1:members)
    {
      if(considered3[i,1] == 0)
      {
        #J= J+1;
        corr_p[i,] = wtd.cor(SCORE_LIST_SET_NORM[,i],p[,1], W3[,1])
        #corr_p[i,] = weightedCorr(SCORE_LIST_SET_NORM[,i],p[,1], method = "Spearman", weights = W3[,1], ML = FALSE, fast = TRUE)
      }
      else
      {
        corr_p[i,1] = 1000;
        corr_p[i,2] = 20;
        corr_p[i,3] = 20
        corr_p[i,4] = 20;
      }
    }
    
    
    corrp_sort = sort(corr_p[,1], decreasing = FALSE, index.return = TRUE);
    corrp_ind <- as.matrix(corrp_sort$ix);
    
    # boosting ..............................................
    
    #outliers_included = matrix(data=0, nrow =points, ncol=1)
    #temp2_pass = matrix(data=0, nrow =points, ncol=1)
    
    #temp2_pass = as.matrix(SCORE_LIST_SET_NORM[,boost_j])
    #outliers_included = convert_binary(temp2_pass,t)
    
    #drop = 0.25
    #chk_pt =0
    #for(i in 1:points)
    #{
      #if((target3[i,1]==1)&&(outliers_included[i,1]==1))
      #{ 
       # chk_pt = chk_pt+1
        #W3[i,1] = W3[i,1]*drop
      #}
    #}
    #chk_pt
    
    drop1 = 0.25
    W3 = boosting1(target3, W3, t, drop1, boost_j, SCORE_LIST_SET_NORM)
    
    
  }  # end if ..........................................................
  count = count-1;
  
}# end while .........................................


sel = sum(selected3[,1])

update=0
for(i in 1:members)
{
  if((selected3[i,1]==1)&&(update==1))
  {
    selected3_ind = cbind(selected3_ind, i) 
  }else if((selected3[i,1]==1)&&(update==0))
  {
    update =1
    selected3_ind = cbind(i)
  }
  
}

selected3_ind





















